 <a href="https://whatsapp.com/channel/0029VaihcQv84Om8LP59fO3f">
 <img alt="FREDI MD" height="300" src="https://i.imgur.com/cb8SxoX.jpeg">

  ## ***FREDI MD MADE BY FREDI EZRA***

  </h1> 
<p align="center">ɪ ɪɴᴛʀᴏᴅᴜᴄᴇ <b>FREDI MD</b>, ᴀ ᴘᴏᴡᴇʀғᴜʟ sɪᴍᴘʟᴇ ᴡᴀᴛsᴀᴘᴘ ʙᴏᴛ </p>




## `FREDI MD SETUP`


1. Fork the repo

<a href='https://github.com/Fred1e/Fredi_Md/fork' target="_blank"><img alt='fork bot repo here' src='https://img.shields.io/badge/fork repo-black?style=for-the-badge&logo=github&logoColor=blue'/></a>





##


#### COMMUNICATE WITH OWNERS 




</details>

<details>
<summary>For Developer And Support💯</summary>
  For Help And Developer Join As Here ✔️
<a href='https://whatsapp.com/channel/0029VaihcQv84Om8LP59fO3f' target="_blank"><img alt='WHATSAPP' src='https://img.shields.io/badge/WhatsApp Channel Support-black?style=for-the-badge&logo=whatsapp&logoColor=green'/></a>

<a href='https://chat.whatsapp.com/BdVxcF4C00J4X4Sa39dpOi' target="_blank"><img alt='WHATSAPP' src='https://img.shields.io/badge/Join WhatsApp Group-black?style=for-the-badge&logo=whatsapp&logoColor=green'/></a>

<a href='https://wa.me/255752593977' target="_blank"><img alt='WHATSAPP' src='https://img.shields.io/badge/Wa Me Here-black?style=for-the-badge&logo=whatsapp&logoColor=green'/></a>

<a href='https://www.youtube.com/@freeonlinetvT1' target="_blank"><img alt='YOUTUBE' src='https://img.shields.io/badge/Tutorial Here In Youtube-black?style=for-the-badge&logo=youtube&logoColor=red'/></a>

<a href='t.me/freditech' target="_blank"><img alt='TELEGRAM' src='https://img.shields.io/badge/Telegram For Dev-black?style=for-the-badge&logo=telegram&logoColor=blue'/></a>

<a href='https://t.me/+u3zlb5y6OfxhOTdk' target="_blank"><img alt='TELEGRAM' src='https://img.shields.io/badge/Telegram Group-black?style=for-the-badge&logo=Telegram&logoColor=blue'/></a>
</details>



##

#### GENERATE SESSION_ID HERE



</details>

<details>
<summary>Get Session Id Here💯</summary>
 Get session id by (SCANNING QR1)
    <a href='https://github.com/Fred1e' target="_blank"><img alt='Follow To Scan Qr Cods' src='https://img.shields.io/badge/Follow To Scan Qr Code-black?style=for-the-badge&logo=git&logoColor=green'/></a>


Get session id by (PAIRING CODE2) 
    <a href='https://fredi-scanner-baa15ec0127c.herokuapp.com/' target="_blank"><img alt='Pair Code Your Here' src='https://img.shields.io/badge/Pair Your Code Here-black?style=for-the-badge&logo=git&logoColor=green'/></a>
</details>




##

#### DEPLOY TO PANEL 



</details>

<details>
<summary>Tap For Info💯</summary>
1. If You don't have a account on panel Create a account.
    <a href='https://bot-hosting.net/?aff=1086839354611212288' target="_blank"><img alt='Create Your Account Now' src='https://img.shields.io/badge/Create Your Account Now-black?style=for-the-badge&logo=discord&logoColor=darkblue'/></a>


2. Now Deploy
   <a href='https://bot-hosting.net/?aff=1086839354611212288' target="_blank"><img alt='Tap Here For Deployment' src='https://img.shields.io/badge/Tap Deploy On Pannel Here-black?style=for-the-badge&logo=discord&logoColor=darkblue'/></a>
</details>


##

#### DEPLOY TO HEROKU 



</details>

<details>
<summary>For Set Up Here💯</summary>
1. If You don't have a account in Heroku. Create a account.
    <a href='https://signup.heroku.com/' target="_blank"><img alt='Create Your Account Here' src='https://img.shields.io/badge/Create Your Account Here-black?style=for-the-badge&logo=heroku&logoColor=purple'/></a>


2. Now Deploy Botton Bot. 
   <a href='https://dashboard.heroku.com/new?template=https://github.com/Fred1e/Fredi_Md' target="_blank"><img alt='Tap Deploy On Heroku Here' src='https://img.shields.io/badge/Deploy To Heroku Here-black?style=for-the-badge&logo=heroku&logoColor=purple'/></a>

  3. Now Deploy Normal Bot.
     <a href='https://dashboard.heroku.com/new?template=https://github.com/kingfredie/LUCKY_MD' target="_blank"><img alt='Tap Deploy On Heroku Here' src='https://img.shields.io/badge/Deploy To Heroku Here-black?style=for-the-badge&logo=heroku&logoColor=purple'/></a>
</details>


##

#### DEPLOY TO RENDER




</details>

<details>
<summary>For Set Up Tap Here💯</summary>

1. If You don't have a account in Render. Create a account.
   <a href='https://dashboard.render.com/register' target="_blank"><img alt='Create Your Account Now' src='https://img.shields.io/badge/Create Your Account Now-black?style=for-the-badge&logo=render&logoColor=blue'/></a>

2. Now Deploy
    <a href='https://dashboard.render.com' target="_blank"><img alt='Deploy On Render Here' src='https://img.shields.io/badge/Deploy On Render Here-black?style=for-the-badge&logo=render&logoColor=blue'/></a>
</details>


##


#### DEPLOY TO REPLIT


</details>

<details>
<summary>Tap For Replit Set💯</summary>

1. If You Don't Have Account In Replit Create Now.
   <a href='https://replit.com' target="_blank"><img alt='replit' src='https://img.shields.io/badge/Create Your Account Here-black?style=for-the-badge&logo=replit&logoColor=orange'/></a>
   
  
3. Now Deploy Button Bot. 
  <a href='https://replit.com/github/Fred1e/Fredi_Md' target="_blank"><img alt='replit' src='https://img.shields.io/badge/DEPLOY ON REPLIT-black?style=for-the-badge&logo=replit&logoColor=orange'/></a>

  3. Now Deploy Normal Bot.
     <a href='https://replit.com/github/Fred1e/Fredi_Md-V1' target="_blank"><img alt='replit' src='https://img.shields.io/badge/DEPLOY ON REPLIT-black?style=for-the-badge&logo=replit&logoColor=orange'/></a>

### HOW TO DEPLOY ON REPLIT

      1.Open account on replit 
      2.Open bot repo then fork. 
      3.Tap deploy button to "deploy on replit". 
      4.Tap import from github 
      5.After importing tap 👈 button down 👇 of replit dashboard. 
      6.Choose config.cjs file then put your session 🆔 and others you need. 
      7.Tap button written run to run your bot then go test it's work. 
    THANK YOU FOR CHOOSING FREDI MD 
  </details>




##



#### ***This One Is Another Fredie Take Safe Bot In Heroku Called Lucky Md Open 🔓 There To Check ☑ This Have More Than 300 Plugins Enjoy***
</details>

<details>
<summary>Tap To Check Lucky Md💯</summary>
 Lucky Md Info
    <a href='https://github.com/Fred1e/LUCKY_MD' target="_blank"><img alt='Open Lucky Md Repo Here😁' src='https://img.shields.io/badge/Open Lucky Md Repo Here😁-black?style=for-the-badge&logo=github&logoColor=green'/></a>


All Information About Me 
    <a href='https://fredi-bio.vercel.app/' target="_blank"><img alt='Owner Info Tap Here😎' src='https://img.shields.io/badge/Owner Info Tap Here😎-black?style=for-the-badge&logo=google&logoColor=red'/></a>
</details>
   

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

