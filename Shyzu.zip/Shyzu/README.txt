//=============================\\

Base Ori Created By MannR
Name Script : Shyzu
Creator Script : MannR
Version Script : 1.0.0
Libary : @whiskeysockets/baileys
Version Libary : ^6.6.0
Created on Sunday, Sep 1, 2024

Thank you to MannR and the module providers and those who use this base.

Please use this base as best as possible and do not delete the copyright.

© MannR 2024

\\=============================//
