const express = require('express');
const bodyParser = require('body-parser');
const nodemailer = require('nodemailer');
const SFTPClient = require('ssh2-sftp-client');
const axios = require('axios');
const fs = require('fs');

const app = express();
const PORT = 3000;

const DB_FILE_PATH = 'database.json';

let database = loadDatabase();

// Function to load data from database file
function loadDatabase() {
    try {
        const data = fs.readFileSync(DB_FILE_PATH, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        console.error('Error loading database:', error);
        return { verifiedUsers: {} };
    }
}

// Function to save data to database file
function saveDatabase(data) {
    try {
        fs.writeFileSync(DB_FILE_PATH, JSON.stringify(data, null, 2));
        console.log('Database saved successfully');
    } catch (error) {
        console.error('Error saving database:', error);
    }
}
const verifiedUsers = database.verifiedUsers;

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));

// Static files
app.use(express.static('public'));

// Nodemailer configuration with SendGrid
const transporter = nodemailer.createTransport({
    host: 'smtp.sendgrid.net',
    port: 587,
    auth: {
        user: 'apikey',
        pass: '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'
    }
});

// In-memory storage for API keys
const apiKeys = {};

// Function to generate random API key
function generateApiKey() {
    return Math.random().toString(36).substr(2, 12);
}

// Helper function to get base URL
function getBaseUrl(req) {
    return `${req.protocol}://${req.get('host')}`;
}

// reCAPTCHA secret key
const recaptchaSecretKey = '6LeQC_YpAAAAABH_kPp9s04zvFyXnkhPlsd7fANN';

// Route for form submission
app.post('/submit', async (req, res) => {
    const { name, email, 'g-recaptcha-response': recaptchaToken } = req.body;

    // Verify reCAPTCHA
    const recaptchaUrl = `https://www.google.com/recaptcha/api/siteverify?secret=${recaptchaSecretKey}&response=${recaptchaToken}`;
    const recaptchaResponse = await axios.post(recaptchaUrl);

    if (!recaptchaResponse.data.success) {
        return res.status(400).send(`
            <html>
            <head>
                <title>Verification Failed</title>
                <style>
                    body {
                        font-family: Arial, sans-serif;
                        background-color: #f4f4f4;
                        display: flex;
                        justify-content: center;
                        align-items: center;
                        height: 100vh;
                        margin: 0;
                    }
                    .container {
                        background-color: #fff;
                        padding: 20px;
                        border-radius: 8px;
                        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
                        max-width: 400px;
                        width: 100%;
                        text-align: center;
                    }
                    h1 {
                        color: #e74c3c;
                    }
                    p {
                        font-size: 16px;
                        margin-bottom: 20px;
                    }
                </style>
            </head>
            <body>
                <div class="container">
                    <h1>Verification Failed</h1>
                    <p>reCAPTCHA verification failed. Please try again.</p>
                </div>
            </body>
            </html>
        `);
    }

    const apiKey = generateApiKey();
    const verificationLink = `${getBaseUrl(req)}/verify?name=${encodeURIComponent(name)}&apikey=${apiKey}`;

    // Store the API key with user data
    apiKeys[apiKey] = { name, email };

    // Email options
    const mailOptions = {
        from: 'pablonetwork.noreply@gmail.com',
        to: email,
        subject: 'Verification Link',
        html: `
            <h1>Email Verification</h1>
            <p>Hello ${name},</p>
            <p>Please verify your name by clicking the button below:</p>
            <a href="${verificationLink}" style="display:inline-block;padding:10px 20px;margin:10px 0;color:#ffffff;background-color:#007bff;border-radius:5px;text-decoration:none;">Verify Now</a>
            <p>If you cannot click the button, copy and paste the following link into your browser:</p>
            <p><a href="${verificationLink}">${verificationLink}</a></p>
            <p>Thank you!</p>
        `
    };

    // Send email
    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            console.error('Error sending email:', error);
            return res.status(500).send(`
                <html>
                <head>
                    <title>Error</title>
                    <style>
                        body {
                            font-family: Arial, sans-serif;
                            background-color: #f4f4f4;
                            display: flex;
                            justify-content: center;
                            align-items: center;
                            height: 100vh;
                            margin: 0;
                        }
                        .container {
                            background-color: #fff;
                            padding: 20px;
                            border-radius: 8px;
                            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
                            max-width: 400px;
                            width: 100%;
                            text-align: center;
                        }
                        h1 {
                            color: #e74c3c;
                        }
                        p {
                            font-size: 16px;
                            margin-bottom: 20px;
                        }
                    </style>
                </head>
                <body>
                    <div class="container">
                        <h1>Error</h1>
                        <p>Error sending email. Please try again later.</p>
                    </div>
                </body>
                </html>
            `);
        }
        res.send(`
            <html>
            <head>
                <title>Email Sent</title>
                <style>
                    body {
                        font-family: Arial, sans-serif;
                        background-color: #f4f4f4;
                        display: flex;
                        justify-content: center;
                        align-items: center;
                        height: 100vh;
                        margin: 0;
                    }
                    .container {
                        background-color: #fff;
                        padding: 20px;
                        border-radius: 8px;
                        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
                        max-width: 400px;
                        width: 100%;
                        text-align: center;
                    }
                    h1 {
                        color: #2ecc71;
                    }
                    p {
                        font-size: 16px;
                        margin-bottom: 20px;
                    }
                </style>
            </head>
            <body>
                <div class="container">
                    <h1>Email Sent</h1>
                    <p>A verification email has been sent to <strong>${email}</strong>. Please check your inbox and follow the instructions to verify your name.</p>
                </div>
            </body>
            </html>
        `);
    });
});

// Route for verification link
app.get('/verify', (req, res) => {
    const { name, apikey } = req.query;

    if (!apikey || !apiKeys[apikey]) {
        return res.status(401).send(`
            <html>
            <head>
                <title>Invalid or Expired API Key</title>
                <style>
                    body {
                        font-family: Arial, sans-serif;
                        background-color: #f4f4f4;
                        display: flex;
                        justify-content: center;
                        align-items: center;
                        height: 100vh;
                        margin: 0;
                    }
                    .container {
                        background-color: #fff;
                        padding: 20px;
                        border-radius: 8px;
                        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
                        max-width: 400px;
                        width: 100%;
                        text-align: center;
                    }
                    h1 {
                        color: #e74c3c;
                    }
                    p {
                        font-size: 16px;
                        margin-bottom: 20px;
                    }
                </style>
            </head>
            <body>
                <div class="container">
                    <h1>Invalid or Expired API Key</h1>
                    <p>The API key is invalid or has expired. Please request a new verification link.</p>
                </div>
            </body>
            </html>
        `);
    }

    const userData = apiKeys[apikey];

    if (verifiedUsers[name]) {
        return res.status(401).send(`
            <html>
            <head>
                <title>Invalid Name</title>
                <style>
                    body {
                        font-family: Arial, sans-serif;
                        background-color: #f4f4f4;
                        display: flex;
                        justify-content: center;
                        align-items: center;
                        height: 100vh;
                        margin: 0;
                    }
                    .container {
                        background-color: #fff;
                        padding: 20px;
                        border-radius: 8px;
                        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
                        max-width: 400px;
                        width: 100%;
                        text-align: center;
                    }
                    h1 {
                        color: #e74c3c;
                    }
                    p {
                        font-size: 16px;
                        margin-bottom: 20px;
                    }
                </style>
            </head>
            <body>
                <div class="container">
                    <h1>Error</h1>
                    <p>Name has already been verified.</p>
                </div>
            </body>
            </html>
        `);
    }

    // Check if the name matches the stored name for this API key
    if (userData.name !== name) {
        return res.status(401).send(`
            <html>
            <head>
                <title>Invalid Name</title>
                <style>
                    body {
                        font-family: Arial, sans-serif;
                        background-color: #f4f4f4;
                        display: flex;
                        justify-content: center;
                        align-items: center;
                        height: 100vh;
                        margin: 0;
                    }
                    .container {
                        background-color: #fff;
                        padding: 20px;
                        border-radius: 8px;
                        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
                        max-width: 400px;
                        width: 100%;
                        text-align: center;
                    }
                    h1 {
                        color: #e74c3c;
                    }
                    p {
                        font-size: 16px;
                        margin-bottom: 20px;
                    }
                </style>
            </head>
            <body>
                <div class="container">
                    <h1>Invalid Name</h1>
                    <p>The name does not match the stored name for this API key. Please request a new verification link.</p>
                </div>
            </body>
            </html>
        `);
    }

    // SFTP configuration
    const sftp = new SFTPClient();
    const sftpConfig = {
        host: 'matrix.lemehost.com',
        port: '2022',
        username: 'user_761055.1f926475',
        password: 'DQEeUJHgIraWaVZTENWxxmQe6mkh2L0p'
    };

    // File to be uploaded
    const remoteFilePath = `/path/on/sftp/${name}.txt`;

    sftp.connect(sftpConfig)
        .then(() => sftp.put(Buffer.from(name), remoteFilePath))
        .then(() => {
            sftp.end();
            delete apiKeys[apikey];
            verifiedUsers[name] = { email: userData.email };
            saveDatabase({ verifiedUsers });
            res.send(`
                <html>
                <head>
                    <title>Verification Successful</title>
                    <style>
                        body {
                            font-family: Arial, sans-serif;
                            background-color: #f4f4f4;
                            display: flex;
                            justify-content: center;
                            align-items: center;
                            height: 100vh;
                            margin: 0;
                        }
                        .container {
                            background-color: #fff;
                            padding: 20px;
                            border-radius: 8px;
                            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
                            max-width: 400px;
                            width: 100%;
                            text-align: center;
                        }
                        h1 {
                            color: #2ecc71;
                        }
                        p {
                            font-size: 16px;
                            margin-bottom: 20px;
                        }
                    </style>
                </head>
                <body>
                    <div class="container">
                        <h1>Verification Successful</h1>
                        <p>Your name has add to database.</p>
                    </div>
                </body>
                </html>
            `);
        })
        .catch(err => {
            console.error(err);
            res.status(500).send(`
                <html>
                <head>
                    <title>Error</title>
                    <style>
                        body {
                            font-family: Arial, sans-serif;
                            background-color: #f4f4f4;
                            display: flex;
                            justify-content: center;
                            align-items: center;
                            height: 100vh;
                            margin: 0;
                        }
                        .container {
                            background-color: #fff;
                            padding: 20px;
                            border-radius: 8px;
                            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
                            max-width: 400px;
                            width: 100%;
                            text-align: center;
                        }
                        h1 {
                            color: #e74c3c;
                        }
                        p {
                            font-size: 16px;
                            margin-bottom: 20px;
                        }
                    </style>
                </head>
                <body>
                    <div class="container">
                        <h1>Error</h1>
                        <p>Error add name to database. Please try again later.</p>
                    </div>
                </body>
                </html>
            `);
        });
});

// Start server
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
